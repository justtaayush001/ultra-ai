# ULTRA AI (v0.1 core)
Open in Android Studio (Koala+) -> Sync -> Run on a real phone. Untested build: expect small compile fixes.

## Works
Hinglish/English text + voice, offline parser, optional Claude cloud parser (key encrypted), 3 security levels
(level is decided in code, never by the cloud), open apps/settings/camera, torch, volume, battery, alarm, timer,
call (confirm), SMS + WhatsApp drafts (confirm), payment apps open-only (Level 3), history, TTS.

## Android does NOT allow (handoff instead)
- Auto-pressing Send in WhatsApp/SMS: draft opens, you tap Send.
- Instagram reel share / DM / comments: no public API. Only opening app/profile is done.
- Entering payment amount or paying: never; official app only.
- Silent Wi-Fi/Bluetooth toggle (Android 10+): opens settings.
- Reading WhatsApp messages: needs Notification Listener (not added yet).
- Always-on wake word / floating button: not yet built (needs foreground service + overlay permission).

## Not built yet
Separate screens (Dashboard/Permissions/Security Center), routines, shortcuts, floating button, wake word.
