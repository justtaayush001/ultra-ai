package com.ultra.ai
import android.Manifest
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.ultra.ai.actions.Executor
import com.ultra.ai.brain.Brain
import com.ultra.ai.brain.Cmd
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        tts = TextToSpeech(this) { tts?.language = Locale("hi", "IN") }
        setContent { UltraApp { tts?.speak(it, TextToSpeech.QUEUE_FLUSH, null, "u") } }
    }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

private fun hist(c: Context) = c.getSharedPreferences("hist", 0)
private fun loadHist(c: Context): List<String> = JSONArray(hist(c).getString("h", "[]")).let { a -> (0 until a.length()).map { a.getString(it) } }
private fun addHist(c: Context, l: String) { val a = JSONArray(); (listOf(l) + loadHist(c)).take(100).forEach { a.put(it) }; hist(c).edit().putString("h", a.toString()).apply() }

@Composable
fun UltraApp(speak: (String) -> Unit) {
    val ctx = LocalContext.current as ComponentActivity
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Bolo ya likho…") }
    var pending by remember { mutableStateOf<Cmd?>(null) }
    var key by remember { mutableStateOf("") }
    val log = remember { mutableStateListOf<String>().apply { addAll(loadHist(ctx)) } }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    LaunchedEffect(Unit) { perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)) }

    fun report(t: String) { status = t; speak(t); log.add(0, t); addHist(ctx, t) }
    fun execute(c: Cmd) { val r = Executor.run(ctx, c); report((if (r.ok) "✓ " else "✗ ") + r.msg) }
    fun handle(text: String) = scope.launch {
        status = "Samajh raha hoon…"
        val c = Brain.parse(ctx, text)
        when {
            c == null -> report("Samajh nahi aaya. Thoda aur clear bolo, ya Settings mein cloud key daalo.")
            c.level == 1 -> execute(c)
            else -> pending = c
        }
    }
    fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { report("Speech recognition available nahi"); return }
        val sr = SpeechRecognizer.createSpeechRecognizer(ctx)
        sr.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onResults(b: Bundle) { b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { input = it; handle(it) }; sr.destroy() }
            override fun onError(e: Int) { status = "Sun nahi paya (error $e)"; sr.destroy() }
            override fun onReadyForSpeech(p: Bundle?) { status = "Sun raha hoon…" }
            override fun onBeginningOfSpeech() {}; override fun onRmsChanged(r: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}; override fun onPartialResults(p: Bundle?) {}; override fun onEvent(t: Int, p: Bundle?) {}
        })
        sr.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN"))
    }

    val pulse by rememberInfiniteTransition(label = "o").animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "s")
    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF7C6CFF))) {
        Column(Modifier.fillMaxSize().background(Color.Black).systemBarsPadding().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("ULTRA AI", color = Color.White, style = MaterialTheme.typography.headlineSmall)
            Text("Your Phone. Your Commands. Your AI.", color = Color(0xFF8E94AB), style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(20.dp))
            Box(Modifier.size(130.dp).scale(pulse).background(Brush.radialGradient(listOf(Color(0xFF7C6CFF), Color(0xFF2B6BFF), Color.Transparent)), CircleShape))
            Spacer(Modifier.height(12.dp)); Text(status, color = Color.White)
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Command likho…") }, singleLine = true)
                Spacer(Modifier.width(8.dp)); Button({ listen() }) { Text("🎤") }
                Spacer(Modifier.width(4.dp)); Button({ if (input.isNotBlank()) { handle(input); input = "" } }) { Text("Go") }
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(key, { key = it }, Modifier.weight(1f), placeholder = { Text(if (Brain.hasKey(ctx)) "Cloud key saved ✓" else "Anthropic API key (optional)") }, singleLine = true)
                Spacer(Modifier.width(8.dp)); Button({ if (key.isNotBlank()) { Brain.saveKey(ctx, key); key = ""; status = "Key encrypted & saved" } }) { Text("Save") }
            }
            Spacer(Modifier.height(10.dp))
            Text("History", color = Color(0xFF8E94AB), modifier = Modifier.align(Alignment.Start))
            LazyColumn(Modifier.weight(1f)) { items(log) { Text(it, color = Color.White, modifier = Modifier.padding(vertical = 4.dp)) } }
        }
        pending?.let { c ->
            AlertDialog(onDismissRequest = { pending = null },
                title = { Text(if (c.level == 3) "High security" else "Confirm karein") },
                text = { Text(if (c.level == 3) "${c.summary}\n\nSirf app khulega. Payment, PIN aur authorize aapko official app mein khud karna hoga." else c.summary) },
                confirmButton = { TextButton({ pending = null; execute(c) }) { Text(if (c.level == 3) "App kholo" else "Haan, karo") } },
                dismissButton = { TextButton({ pending = null; report("Cancel kiya") }) { Text("Nahi") } })
        }
    }
}
