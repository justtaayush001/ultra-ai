package com.ultra.ai.brain
import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Cmd(val action: String, val args: Map<String, String>, val level: Int, val summary: String)

object Security {
    // Level is decided HERE, never by the cloud model.
    fun level(action: String, args: Map<String, String>): Int = when (action) {
        "payment_open" -> 3
        "whatsapp_msg", "sms", "call" -> 2
        "open_app" -> if (isPayment(args["name"] ?: "")) 3 else 1
        else -> 1
    }
    fun isPayment(n: String) = listOf("phonepe", "gpay", "google pay", "paytm", "bhim", "upi").any { n.lowercase().contains(it) }
}

object Brain {
    private fun mk(a: String, args: Map<String, String>, s: String) = Cmd(a, args, Security.level(a, args), s)

    suspend fun parse(ctx: Context, text: String): Cmd? = offline(text) ?: cloud(ctx, text)

    fun offline(raw: String): Cmd? {
        val t = raw.lowercase().trim(); val I = RegexOption.IGNORE_CASE
        if ("battery" in t) return mk("battery", emptyMap(), "Battery check")
        if ("torch" in t || "flash" in t) {
            val on = listOf("off", "band", "bund", "bujha").none { it in t }
            return mk("flashlight", mapOf("on" to on.toString()), "Flashlight ${if (on) "on" else "off"}")
        }
        if ("volume" in t) {
            Regex("""(\d{1,3})""").find(t)?.let { return mk("volume", mapOf("pct" to it.value), "Volume ${it.value}%") }
            val dir = if (listOf("down", "kam", "low").any { it in t }) "down" else "up"
            return mk("volume", mapOf("dir" to dir), "Volume $dir")
        }
        if ("brightness" in t) return mk("brightness", mapOf("pct" to (Regex("""(\d{1,3})""").find(t)?.value ?: "50")), "Brightness")
        if ("alarm" in t) Regex("""(\d{1,2})(?:[:.](\d{2}))?\s*(am|pm)?""").find(t)?.let {
            var h = it.groupValues[1].toInt(); val m = it.groupValues[2].ifEmpty { "0" }.toInt()
            if (it.groupValues[3] == "pm" && h < 12) h += 12
            return mk("alarm", mapOf("h" to "$h", "m" to "$m"), "Alarm %02d:%02d".format(h, m))
        }
        if ("timer" in t) Regex("""(\d+)\s*(second|sec|minute|min|mint)""").find(t)?.let {
            val s = it.groupValues[1].toInt() * (if (it.groupValues[2].startsWith("s")) 1 else 60)
            return mk("timer", mapOf("sec" to "$s"), "Timer ${it.groupValues[1]} ${it.groupValues[2]}")
        }
        Regex("""(\w+)\s+ko\s+(?:message|msg|sms)\s+bhej\w*\s+(?:ki\s+|ke\s+)?(.+)""", I).find(raw)
            ?: Regex("""(?:send\s+)?(?:a\s+)?(?:whatsapp\s+)?(?:message|msg|sms)\s+to\s+(\w+)\s+(?:saying\s+|that\s+)?(.+)""", I).find(raw)
            ?.let {
                val sms = "sms" in t
                return mk(if (sms) "sms" else "whatsapp_msg", mapOf("to" to it.groupValues[1], "text" to it.groupValues[2].trim()),
                    "${if (sms) "SMS" else "WhatsApp"} to ${it.groupValues[1]}: ${it.groupValues[2].trim()}")
            }
        (Regex("""(\w+)\s+ko\s+call""", I).find(raw) ?: Regex("""call\s+(\w+)""", I).find(raw))?.let {
            return mk("call", mapOf("to" to it.groupValues[1]), "Call ${it.groupValues[1]}")
        }
        Regex("""(?:open\s+)?(.+?)\s*(?:kholo|khol do|open karo|open kar)""", I).find(raw)?.let { return mk("open_app", mapOf("name" to it.groupValues[1].trim()), "Open ${it.groupValues[1].trim()}") }
        Regex("""^open\s+(.+)""", I).find(raw)?.let { return mk("open_app", mapOf("name" to it.groupValues[1].trim()), "Open ${it.groupValues[1].trim()}") }
        return null
    }

    private fun prefs(ctx: Context) = EncryptedSharedPreferences.create(ctx, "ultra_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    fun saveKey(ctx: Context, k: String) = prefs(ctx).edit().putString("api_key", k.trim()).apply()
    fun hasKey(ctx: Context) = !prefs(ctx).getString("api_key", "").isNullOrBlank()

    /** Cloud fallback for Hindi/Hinglish/complex commands. Returns null if no key or no match. */
    private suspend fun cloud(ctx: Context, text: String): Cmd? = withContext(Dispatchers.IO) {
        val key = prefs(ctx).getString("api_key", "") ?: ""; if (key.isBlank()) return@withContext null
        try {
            val sys = "Convert the user's Hindi/English/Hinglish phone command into ONE JSON object only: " +
                "{\"action\":one of open_app|battery|flashlight|volume|alarm|timer|whatsapp_msg|sms|call|none,\"args\":{string:string},\"summary\":string}. " +
                "args: open_app{name}; flashlight{on:true/false}; volume{pct}; alarm{h,m}; timer{sec}; whatsapp_msg/sms{to,text}; call{to}. Use none if unclear. Never output payments."
            val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 300).put("system", sys)
                .put("messages", org.json.JSONArray().put(JSONObject().put("role", "user").put("content", text)))
            val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 30000
            c.setRequestProperty("content-type", "application/json"); c.setRequestProperty("x-api-key", key)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val out = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("content").getJSONObject(0).getString("text")
            val j = JSONObject(out.substring(out.indexOf('{'), out.lastIndexOf('}') + 1))
            val a = j.getString("action"); if (a == "none") return@withContext null
            val args = j.optJSONObject("args")?.let { o -> o.keys().asSequence().associateWith { o.getString(it) } } ?: emptyMap()
            mk(a, args, j.optString("summary", a))
        } catch (e: Exception) { null }
    }
}
