package com.ultra.ai.actions
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.MediaStore
import android.provider.Settings
import com.ultra.ai.brain.Cmd

data class Res(val ok: Boolean, val msg: String)

object Executor {
    private val pkgs = mapOf("whatsapp" to "com.whatsapp", "instagram" to "com.instagram.android", "phonepe" to "com.phonepe.app",
        "paytm" to "net.one97.paytm", "gpay" to "com.google.android.apps.nbu.paisa.user", "google pay" to "com.google.android.apps.nbu.paisa.user")

    fun run(c: Context, cmd: Cmd): Res = try { exec(c, cmd) } catch (e: Exception) { Res(false, "Fail hua: ${e.message}") }

    private fun go(c: Context, i: Intent): Boolean { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i); return true }

    private fun number(c: Context, name: String): String? = try {
        c.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.NUMBER), "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)
            ?.use { if (it.moveToFirst()) it.getString(0).filter { ch -> ch.isDigit() || ch == '+' } else null }
    } catch (e: SecurityException) { null }

    private fun openApp(c: Context, name: String): Res {
        val n = name.lowercase()
        if (n.contains("camera")) { go(c, Intent(MediaStore.ACTION_IMAGE_CAPTURE)); return Res(true, "Camera khola") }
        if (n.contains("wifi") || n.contains("wi-fi")) { go(c, Intent(Settings.ACTION_WIFI_SETTINGS)); return Res(true, "Wi-Fi settings khuli") }
        if (n.contains("bluetooth")) { go(c, Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return Res(true, "Bluetooth settings khuli") }
        if (n == "settings") { go(c, Intent(Settings.ACTION_SETTINGS)); return Res(true, "Settings khuli") }
        val pm = c.packageManager
        val pkg = pkgs[n] ?: pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }?.activityInfo?.packageName
        val i = pkg?.let { pm.getLaunchIntentForPackage(it) } ?: return Res(false, "'$name' app nahi mila")
        go(c, i); return Res(true, "$name khola")
    }

    private fun exec(c: Context, cmd: Cmd): Res {
        val a = cmd.args
        return when (cmd.action) {
            "open_app", "payment_open" -> openApp(c, a["name"] ?: "")
            "battery" -> Res(true, "Battery ${(c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}%")
            "flashlight" -> {
                val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                    ?: return Res(false, "Flash nahi mila")
                val on = a["on"] == "true"; cm.setTorchMode(id, on); Res(true, "Torch ${if (on) "on" else "off"}")
            }
            "volume" -> {
                val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager; val s = AudioManager.STREAM_MUSIC
                a["pct"]?.toIntOrNull()?.let { am.setStreamVolume(s, am.getStreamMaxVolume(s) * it.coerceIn(0, 100) / 100, AudioManager.FLAG_SHOW_UI) }
                    ?: am.adjustStreamVolume(s, if (a["dir"] == "down") AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                Res(true, "Volume badla")
            }
            "brightness" -> if (Settings.System.canWrite(c)) {
                Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 255 * (a["pct"]?.toIntOrNull() ?: 50).coerceIn(0, 100) / 100)
                Res(true, "Brightness set")
            } else { go(c, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${c.packageName}"))); Res(false, "Pehle 'Modify system settings' allow karein, fir dobara bolein") }
            "alarm" -> { go(c, Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, a["h"]!!.toInt()).putExtra(AlarmClock.EXTRA_MINUTES, a["m"]!!.toInt())); Res(true, "Alarm screen khuli (clock app ne set kiya)") }
            "timer" -> { go(c, Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, a["sec"]!!.toInt())); Res(true, "Timer set request bheji") }
            "call" -> { val n = number(c, a["to"] ?: "") ?: return Res(false, "Contact nahi mila / permission nahi")
                try { go(c, Intent(Intent.ACTION_CALL, Uri.parse("tel:$n"))) } catch (e: SecurityException) { go(c, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n"))) }
                Res(true, "Call lagayi: ${a["to"]}") }
            "sms" -> { val n = number(c, a["to"] ?: "") ?: return Res(false, "Contact nahi mila")
                go(c, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n")).putExtra("sms_body", a["text"]))
                Res(true, "SMS draft khula. Send aapko khud dabana hai.") }
            "whatsapp_msg" -> { var n = number(c, a["to"] ?: "")?.removePrefix("+") ?: return Res(false, "Contact nahi mila")
                if (n.length == 10) n = "91$n"
                go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n?text=${Uri.encode(a["text"])}")).setPackage("com.whatsapp"))
                Res(true, "WhatsApp chat khuli, message draft hai. Send aapko khud dabana hai.") }
            else -> Res(false, "Yeh action supported nahi hai")
        }
    }
}
