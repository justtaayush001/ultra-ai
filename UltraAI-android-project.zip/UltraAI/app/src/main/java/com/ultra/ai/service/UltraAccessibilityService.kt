package com.ultra.ai.service
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/** Optional, user-enabled. Currently only global Back/Home. It does NOT auto-press Send or touch payment apps. */
class UltraAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }
    companion object {
        var instance: UltraAccessibilityService? = null
        fun back() = instance?.performGlobalAction(GLOBAL_ACTION_BACK) ?: false
        fun home() = instance?.performGlobalAction(GLOBAL_ACTION_HOME) ?: false
    }
}
